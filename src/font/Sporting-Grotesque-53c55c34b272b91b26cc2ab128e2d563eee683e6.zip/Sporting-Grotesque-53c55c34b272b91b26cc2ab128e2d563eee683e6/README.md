# Sporting Grotesque

A grotesque typeface by [Lucas Le Bihan](http://lucaslebihan.fr/).

Greek by [George Triantafyllakos](http://backpacker.gr).

Polish diacritics added by [Maciej Połczyński](http://maciej.polczynski.com/).

Sporting Grotesque is a typeface released by [Velvetyne Type Foundry](http://velvetyne.fr).

![Specimen](documentation/specimen.png)

## Présentation

```
C’est une équipe de ligue 1.

Son hymne :
(librement inspiré d’une composition de Pierre Bachelet)

La victoire au bout du pied
Le ballon au fond des filets
L’ennemi désemparé
Nous vaincrons, nous serons les premiers
Allez Sporting Sporting Grotesque,
But ! But ! But !
```

## Features

```
En plus d’un jeu de caractère comprenant
Petites capitales et chiffres suspendus,
le Sporting Grotesque offre des options de titrage
opentype disponibles dans l’option « Titling Alternates ».

Merci,
Lucas Le Bihan
```

## Licence

SIL Open Font License v1.1
